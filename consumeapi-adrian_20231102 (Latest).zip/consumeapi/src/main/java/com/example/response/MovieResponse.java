package com.example.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MovieResponse {
	private int mov_id;
	private String mov_title;
	private String mov_description;
	private int mov_relyear; 
	private String mov_language; 
	private int mov_runtime;
	private String mov_director;
	private String mov_actor;
	private double mov_rating;
	private int mov_genre_id;
	private String mov_genre;
}
