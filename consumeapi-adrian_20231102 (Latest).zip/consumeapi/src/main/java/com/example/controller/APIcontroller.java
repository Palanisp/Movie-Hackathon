package com.example.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.client.RestTemplate;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.response.MovieResponse;
import com.example.response.GenreResponse;

@Controller 
public class APIcontroller 
{
	@Autowired
	private final  RestTemplate restTemplate;
	
	public APIcontroller (RestTemplate restTemplate) 
	{	this.restTemplate = restTemplate;
	}
	

	@Autowired
	private RestTemplate restobj;
	int id;

	
	@Autowired
	private LoadBalancerClient loadbal;
	
	@GetMapping("/")
	public String LandingPage()
	{
		return "home";
	}

	//== MOVIE CONTROLLERS ========================================================
    @GetMapping("/movies")
	public String ShowMovies (Model model) {
    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String MovieListUri=movie_uri+"/movie-app/api/movies/list";

    	ResponseEntity<List<MovieResponse>> response = restTemplate.exchange(
					MovieListUri,
				    HttpMethod.GET,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
		);

    	ServiceInstance genre_service= loadbal.choose("GENRE-API");
    	String genre_uri=genre_service.getUri().toString();
		 for(MovieResponse mov:response.getBody())
		 {
			 int genreID = mov.getMov_genre_id();
			 String GenreByIDUri=genre_uri+"/movie-genre/api/genres/id?genre_id="+genreID;

			 GenreResponse genre= restobj.getForObject(GenreByIDUri, GenreResponse.class);
			 mov.setMov_genre(genre.getGenre_name());
			 System.out.println(mov);
		 }
		 List <MovieResponse> movies = response.getBody();
		 model.addAttribute("movies", movies);
		 
	     return "movielist";
	}
    
    //DELETE MOVIE
    @GetMapping(value="/delete/{id}")
    public String DeleteMovie(@PathVariable int id, RedirectAttributes redirectAttributes) {

    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String DeleteMovieUri=movie_uri+"/movie-app/api/movies/delete/" + id;

		ResponseEntity<Void> response = restobj.exchange(
				 DeleteMovieUri,
				 HttpMethod.DELETE,
				 null,
				 Void.class,
				 id
		);   	
    	
		//TODO:Status handling not working yet. Need to look into this at a later time.
		if (response.getStatusCode().is2xxSuccessful()) {
			redirectAttributes.addFlashAttribute("message", "Movie deleted successfully.");
			System.out.println("Record "+ id + " deleted successfully.");
		}
		else {
			redirectAttributes.addFlashAttribute("error", "Failed to delete the movie.");
			System.out.println("Failed to delete record.");
		}  

	     return "redirect:/movies";
	}

    //ADD MOVIE
    @GetMapping("/addmovie")
	public String ShowMovieForm(Model model)
	{
    	ServiceInstance genre_service= loadbal.choose("GENRE-API");
    	String genre_uri=genre_service.getUri().toString();
    	String GenreListUri=genre_uri+"/movie-genre/api/genres/list";

    	ResponseEntity<List<GenreResponse>> response = restTemplate.exchange(
    				GenreListUri,
				    HttpMethod.GET,
				    null,
				    new ParameterizedTypeReference<List<GenreResponse>>() {}
		);		

		if (response.getStatusCode().is2xxSuccessful()) {
	    	List <GenreResponse> genres = response.getBody();
			model.addAttribute("genres", genres); 
			System.out.println("Add Movie - ShowMovieForm() - Genres fetched successfully.");
		}
		else {
			model.addAttribute("genres", Collections.emptyList()); 
			System.out.println("Add Movie - ShowMovieForm() - Failed to fetch genres.");
		}  
   	
    	return "addmovie";
	}
    
    @PostMapping("/addmovie")
    public String AddMovie(@ModelAttribute MovieResponse movie, Model model, RedirectAttributes redirectAttributes) {

    	HttpHeaders headers = new HttpHeaders();
    	headers.set("Accept", "application/json");
    	headers.set("Content-Type", "application/json");
    	
    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String AddMovieUri=movie_uri+"/movie-app/api/movies/add";

		ResponseEntity<MovieResponse> response = restobj.exchange(
				 AddMovieUri,
				 HttpMethod.POST,
				 new HttpEntity<>(movie, headers),
				 MovieResponse.class
		);   
    	
		if (response.getStatusCode().is2xxSuccessful()) {
			redirectAttributes.addFlashAttribute("message", "Movie added successfully.");
			System.out.println("Movie added successfully.");
		    return "redirect:/movies";
		} 
		else {
			redirectAttributes.addFlashAttribute("error", "Failed to add movie.");
			System.out.println("Failed to add movie.");
		    return "redirect:/addmovie";
		}  

    }
    
    //EDIT MOVIE
    @GetMapping(value="/edit/{id}")
    public String EditMovie(@PathVariable int id, Model model) {

    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String MovieDetailUri=movie_uri+"/movie-app/api/movies/" + id;

		ResponseEntity<MovieResponse> response = restobj.exchange(
				MovieDetailUri,
				HttpMethod.GET,
				null,
				MovieResponse.class
		);   	
    	
		//TODO:Status handling not working yet. Need to look into this at a later time.
		if (response.getStatusCode().is2xxSuccessful()) {
			MovieResponse movie = response.getBody();
			model.addAttribute("movie", movie);

	    	ServiceInstance genre_service= loadbal.choose("GENRE-API");
	    	String genre_uri=genre_service.getUri().toString();
	    	String GenreListUri=genre_uri+"/movie-genre/api/genres/list";

	    	ResponseEntity<List<GenreResponse>> genre_response = restTemplate.exchange(
	    				GenreListUri,
					    HttpMethod.GET,
					    null,
					    new ParameterizedTypeReference<List<GenreResponse>>() {}
			);		

			if (response.getStatusCode().is2xxSuccessful()) {
		    	List <GenreResponse> genres = genre_response.getBody();
				model.addAttribute("genres", genres); 
				System.out.println("Edit Movie - EditMovie() - Genres fetched successfully.");
			}
			else {
				model.addAttribute("genres", Collections.emptyList()); 
				System.out.println("Edit Movie - EditMovie() - Failed to fetch genres.");
			}
			
			return "editmovie";
		}
		else {
			model.addAttribute("error", "Failed to fetch movie from the service.");
			System.out.println("Failed to fetch movie from the service.");
		}  

	     return "redirect:/movies";
	}    
 
    //SAVE MOVIE CHANGES
    @PostMapping(value="/edit/{id}")
    public String UpdateMovie(@PathVariable int id, 
    		@ModelAttribute MovieResponse movie, 
    		Model model, 
    		RedirectAttributes redirectAttributes) {

    	HttpHeaders headers = new HttpHeaders();
    	headers.set("Accept", "application/json");
    	headers.set("Content-Type", "application/json");
    	
    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String MovieEditUri=movie_uri+"/movie-app/api/movies/edit";

		ResponseEntity<Void> response = restobj.exchange(
				MovieEditUri,
				HttpMethod.PUT,
				new HttpEntity<>(movie, headers),
				Void.class,
				id
		);   	
    	
		//TODO:Status handling not working yet. Need to look into this at a later time.
		if (response.getStatusCode().is2xxSuccessful()) {
			redirectAttributes.addFlashAttribute("message", "Movie edited successfully.");
			System.out.println("Movie "+ id + " edited successfully.");
		}
		else {
			redirectAttributes.addFlashAttribute("error", "Failed to edit the movie.");
			System.out.println("Failed to edit record.");
		}  

	     return "redirect:/movies";
	}        
}

