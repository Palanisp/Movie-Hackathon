package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Movie;
import com.example.repository.MovieRepository;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieRepository repo;	
	
	@Override
	public Movie getMovieBasedOnId(int id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Movie> GetAllMovies() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	@Override
	public Movie addMovie(Movie movie) {
		// TODO Auto-generated method stub
		return repo.save(movie);
	}

	@Override
	public Movie updateMovie(Movie movie) {
		// TODO Auto-generated method stub
		return repo.save(movie);
	}

	@Override
	public void deleteMovie(Movie movie) {
		// TODO Auto-generated method stub
		repo.delete(movie);
	}

}
