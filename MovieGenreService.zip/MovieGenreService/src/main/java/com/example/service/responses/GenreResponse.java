package com.example.service.responses;

import lombok.*;

@Getter
@Setter
@ToString
public class GenreResponse
{
	private int genre_id;
	private String genre_name;
}
