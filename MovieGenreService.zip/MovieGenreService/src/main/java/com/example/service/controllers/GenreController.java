package com.example.service.controllers;

import com.example.service.entity.Genre;
import com.example.service.responses.GenreResponse;
import com.example.service.services.MovieGenreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/genres/")
public class GenreController {
    @Autowired
    private RestTemplate restobj;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private MovieGenreService serv;

    @GetMapping("/id")
    public ResponseEntity<GenreResponse> GetById(@RequestParam int genre_id) {
        Genre emp = serv.getMovieGenreById(genre_id);
        GenreResponse resp = modelMapper.map(emp, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }

    @GetMapping("/list")
    public ResponseEntity<List<Genre>> GetAll() {
        List<Genre> genres = serv.getAllGenres();
        return ResponseEntity.status(HttpStatus.OK).body(genres);
    }

    @PostMapping("/add")
    public ResponseEntity<GenreResponse> AddNew(@RequestBody Genre gen) {
        Genre genre = serv.addNewGenre(gen);
        GenreResponse resp = modelMapper.map(genre, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }

    @PutMapping("/update")
    public ResponseEntity<GenreResponse> Update(@RequestBody Genre gen) {
        Genre genre = serv.updateGenre(gen);
        GenreResponse resp = modelMapper.map(genre, GenreResponse.class);

        return ResponseEntity.status(HttpStatus.OK).body(resp);
    }
}
