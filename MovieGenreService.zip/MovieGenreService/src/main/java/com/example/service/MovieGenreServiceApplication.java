package com.example.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieGenreServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieGenreServiceApplication.class, args);
	}

}
