package com.example.service.services;

import com.example.service.entity.Genre;

import java.util.List;

public interface MovieGenreService {
    Genre getMovieGenreById(int genre_id);

    List<Genre> getAllGenres();

    Genre addNewGenre(Genre genre);

    Genre updateGenre(Genre genre);
}
