package com.example.Moviegenre.services;

import com.example.Moviegenre.entity.Genre;

import java.util.List;

public interface MovieGenreService {
    Genre getMovieGenreById(int genre_id);

    List<Genre> getAllGenres();

    Genre addNewGenre(Genre genre);

    Genre updateGenre(Genre genre);
}
