package com.example.Moviegenre.services;

import com.example.Moviegenre.entity.Genre;
import com.example.Moviegenre.repository.GenreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieGenreServiceImpl implements MovieGenreService {
    @Autowired
    private GenreRepository repo;

    @Override
    public Genre getMovieGenreById(int genre_id) {
        return repo.findById(genre_id).get();
    }

    @Override
    public List<Genre> getAllGenres() {
        return repo.findAll();
    }

    @Override
    public Genre addNewGenre(Genre genre) {
        return repo.save(genre);
    }

    @Override
    public Genre updateGenre(Genre genre) {
        return repo.save(genre);
    }

}
