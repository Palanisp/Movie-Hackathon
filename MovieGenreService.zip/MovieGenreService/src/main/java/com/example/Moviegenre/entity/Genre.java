package com.example.Moviegenre.entity;

import lombok.*;

import javax.persistence.*;

@Getter
@Setter
@Entity
@Table(name="genre")
public class Genre {
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int genre_id;

	@Column(nullable=false)
	private String genre_name;
}
