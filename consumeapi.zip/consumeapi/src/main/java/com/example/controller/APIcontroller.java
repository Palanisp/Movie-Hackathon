package com.example.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.response.MovieResponse;
import com.model.Movie;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class APIcontroller {
	@Autowired
	private RestTemplate restobj;

	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView mav = new ModelAndView("index");
		ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				"http://172.20.0.170:8081/movie-app/api/movies/list", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<MovieResponse>>() {
				});
		for (MovieResponse mov : response.getBody()) {
			System.out.println(mov);
		}
		mav.addObject("movies", response.getBody());
		return mav;
	}

	@GetMapping("/search")
	public ModelAndView search(@RequestParam Integer id) {
		ModelAndView mav = new ModelAndView("index");
		ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				"http://172.20.0.170:8081/movie-app/api/movies/list", HttpMethod.GET, null,
				new ParameterizedTypeReference<List<MovieResponse>>() {
				});
		List<MovieResponse> res = response.getBody().stream().filter(movie -> id.equals(movie.getMov_genre_id()))
				.collect(Collectors.toList());
		mav.addObject("movies", res);
		return mav;
	}

	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable Integer id) {
		// ModelAndView mav=new ModelAndView("delete");
//    	 HttpEntity<?> entity = new HttpEntity();

		String url = "http://172.20.0.170:8081/movie-app/api/movies/delete/" + id;
		restobj.delete(url);

//    	ResponseEntity<List<Movie>> response = restobj.exchange(
//				    "http://172.20.0.170:8081/movie-app/api/movies/delete/{id}/"+id,
//				    HttpMethod.DELETE,
//				    null,
//				    new ParameterizedTypeReference<List<Movie>>() {}
//				   );
		// mav.addObject("movies",response.getBody());
		// if response.ok()
		// return "redirect:/";
		System.out.println("end");
		// return ResponseEntity.ok("Deleted Successfully!");
		return "redirect:/";

	}

	@PostMapping("/add")
	public String add(HttpServletRequest request) {
		// ModelAndView mav=new ModelAndView("delete");
		Movie mov = new Movie();
		mov.setMov_id(Integer.valueOf(request.getParameter("mov_id")));
		mov.setMov_title(request.getParameter("mov_title"));
		mov.setMov_description(request.getParameter("mov_description"));
		mov.setMov_relyear(Integer.valueOf(request.getParameter("mov_relyear")));
		mov.setMov_language(request.getParameter("mov_language"));
		mov.setMov_runtime(Integer.valueOf(request.getParameter("mov_runtime")));
		mov.setMov_director(request.getParameter("mov_director"));
		mov.setMov_actor(request.getParameter("mov_actor"));
		mov.setMov_rating(Double.valueOf(request.getParameter("mov_rating")));
		mov.setMov_genre_id(Integer.valueOf(request.getParameter("mov_genre_id")));
		HttpEntity<?> entity = new HttpEntity(mov);
//    	 ModelAndView mav=new ModelAndView("index");
		ResponseEntity<Movie> addRes = restobj.exchange("http://172.20.0.170:8081/movie-app/api/movies/add",
				HttpMethod.POST, entity, new ParameterizedTypeReference<Movie>() {
				});
		// mav.addObject("movies",response.getBody());
		// if response.ok()
//		 ResponseEntity<List<MovieResponse>> response = restobj.exchange(
//				    "http://172.20.0.170:8081/movie-app/api/movies/list",
//				    HttpMethod.GET,
//				    null,
//				    new ParameterizedTypeReference<List<MovieResponse>>() {}
//				);
//		 mav.addObject("movies",response.getBody());
//	        return mav;

		return "redirect:/";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String add() {
		return "add";
	}

	@GetMapping("/update")
	public String update(HttpServletRequest request) {
		Movie mov = new Movie();
		mov.setMov_id(Integer.valueOf(request.getParameter("mov_id")));
		mov.setMov_title(request.getParameter("mov_title"));
		mov.setMov_description(request.getParameter("mov_description"));
		mov.setMov_relyear(Integer.valueOf(request.getParameter("mov_relyear")));
		mov.setMov_language(request.getParameter("mov_language"));
		mov.setMov_runtime(Integer.valueOf(request.getParameter("mov_runtime")));
		mov.setMov_director(request.getParameter("mov_director"));
		mov.setMov_actor(request.getParameter("mov_actor"));
		mov.setMov_rating(Double.valueOf(request.getParameter("mov_rating")));
		mov.setMov_genre_id(Integer.valueOf(request.getParameter("mov_genre_id")));
		HttpEntity<?> entity = new HttpEntity(mov);
		ResponseEntity<Movie> addRes = restobj.exchange("http://172.20.0.170:8081/movie-app/api/movies/edit",
				HttpMethod.PUT, entity, new ParameterizedTypeReference<Movie>() {
				});
		return "redirect:/";
	}

	@RequestMapping(value = "/edit/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable Integer id) {
		ModelAndView mav = new ModelAndView("edit");
		String url = "http://172.20.0.170:8081/movie-app/api/movies/" + id;
		ResponseEntity<MovieResponse> response = restobj.getForEntity(url, MovieResponse.class);
//		ResponseEntity<List<MovieResponse>> response = restobj.exchange(
//				"http://172.20.0.170:8081/movie-app/api/movies/list", HttpMethod.GET, null,
//				new ParameterizedTypeReference<List<MovieResponse>>() {
//				});
//		for (MovieResponse mov : response.getBody()) {
//			System.out.println(mov);
//		}
		mav.addObject("movie", response.getBody());
		return mav;
	}
}
