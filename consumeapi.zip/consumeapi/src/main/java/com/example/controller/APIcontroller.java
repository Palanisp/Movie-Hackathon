package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.example.response.MovieResponse;

@Controller 
public class APIcontroller 
{
	@Autowired
	private RestTemplate restobj;
	
	int id;
	
	
	
    @RequestMapping("/")
       public ModelAndView index() {
    	 ModelAndView mav=new ModelAndView("index");
		 ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				    "http://172.20.0.170:8081/movie-app/api/movies/list",
				    HttpMethod.GET,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
				);
		  for(MovieResponse mov:response.getBody())
		 {
			 System.out.println(mov);
		 }
		 mav.addObject("movies",response.getBody());
	        return mav;
	    }

    @RequestMapping("/delete/{id}")
    public ResponseEntity<String> delete(Integer id) {
 	// ModelAndView mav=new ModelAndView("delete");
    	//HttpEntity<?> entity = new HttpEntity();
		 ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				    "http://172.20.0.170:8081/movie-app/api/movies/delete/"+ id,
				    HttpMethod.DELETE,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
				   );
	//  mav.addObject("movies",response.getBody());
		   //if response.ok()
	    //    return "redirect:/";
		 return ResponseEntity.ok("Deleted Successfully!");
		 
	    }

    @RequestMapping("/add/{id}")
    public String add(Integer id) {
 	// ModelAndView mav=new ModelAndView("delete");
    	//HttpEntity<?> entity = new HttpEntity();
		 ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				    "http://172.20.0.170:8081/movie-app/api/movies/delete/"+id,
				    HttpMethod.DELETE,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
				   );
	//  mav.addObject("movies",response.getBody());
		   //if response.ok()
	        return "redirect:/";
	    }   
}

