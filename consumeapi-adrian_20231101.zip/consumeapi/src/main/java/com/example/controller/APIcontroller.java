package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.response.MovieResponse;
import com.example.response.GenreResponse;

@Controller 
public class APIcontroller 
{
	@Autowired
	private final  RestTemplate restTemplate;
	
	public APIcontroller (RestTemplate restTemplate) 
	{	this.restTemplate = restTemplate;
	}
	

	@Autowired
	private RestTemplate restobj;
	int id;

	
	@Autowired
	private LoadBalancerClient loadbal;
	
	@GetMapping("/")
	public String LandingPage()
	{
		return "home";
	}

	//== MOVIE CONTROLLERS ========================================================
    @GetMapping("/movies")
	public String showMovies (Model model) {
    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String MovieListUri=movie_uri+"/movie-app/api/movies/list";

    	ResponseEntity<List<MovieResponse>> response = restTemplate.exchange(
					MovieListUri,
				    HttpMethod.GET,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
		);

    	ServiceInstance genre_service= loadbal.choose("GENRE-API");
    	String genre_uri=genre_service.getUri().toString();
		 for(MovieResponse mov:response.getBody())
		 {
			 int genreID = mov.getMov_genre_id();
			 String GenreByIDUri=genre_uri+"/movie-genre/api/genres/id?genre_id="+genreID;

			 GenreResponse genre= restobj.getForObject(GenreByIDUri, GenreResponse.class);
			 mov.setMov_genre(genre.getGenre_name());
			 System.out.println(mov);
		 }
		 List <MovieResponse> movies = response.getBody();
		 model.addAttribute("movies", movies);
		 
	     return "movielist";
	}
    
    @GetMapping(value="/delete/{id}")
    public String deleteMovie(@PathVariable int id, RedirectAttributes redirectAttributes) {

    	ServiceInstance movie_service= loadbal.choose("MOVIE-API");
    	String movie_uri=movie_service.getUri().toString();
    	String DeleteMovieUri=movie_uri+"/movie-app/api/movies/delete/" + id;

		ResponseEntity<Void> response = restobj.exchange(
				 DeleteMovieUri,
				 HttpMethod.DELETE,
				 null,
				 Void.class,
				 id
		);   	
    	
		//TODO:Status handling not working yet. Need to look into this at a later time.
		if (response.getStatusCode().is2xxSuccessful()) {
			redirectAttributes.addFlashAttribute("message", "Movie deleted successfully.");
			System.out.println("Record "+ id + " deleted successfully.");
		}
		else {
			redirectAttributes.addFlashAttribute("error", "Failed to delete the movie.");
			System.out.println("Failed to delete record.");
		}  

	     return "redirect:/movies";
	}

    @RequestMapping("/add/{id}")
    public String add(Integer id) {
 	// ModelAndView mav=new ModelAndView("delete");
    	//HttpEntity<?> entity = new HttpEntity();
		 ResponseEntity<List<MovieResponse>> response = restobj.exchange(
				    "http://172.20.0.170:8081/movie-app/api/movies/delete/"+id,
				    HttpMethod.DELETE,
				    null,
				    new ParameterizedTypeReference<List<MovieResponse>>() {}
				   );
	//  mav.addObject("movies",response.getBody());
		   //if response.ok()
	        return "redirect:/";
	    }   
}

